"""
Hi Fellows

I know y'all thought you were signing up for a service organization, or maybe a way to meet people who go to the President's Tailgate. I did too. I know y'all take this seriously. But I want you to consider whether there is a level of seriousness even appropriate for the sheer magnitude of the University Fellows Experience's intrusion into its students lives. I know it's based on my favorite TV shows. I know there's a "Ratatouille" metaphor that makes it feel like no big deal. Just remember y'all are the perpetrators.

True toxicity. Not the fun stuff. This is worse than frat hazing. I would have rather they broke my arm than my heart. I would rather wish the world were sane than be insane myself. Will the inside jokes make up for two lost years of life? What I thought were to be some of my best? Which I worked all my life to make some of my best?

I don't know how many hundreds of times I have to castigate you to end this nightmare. Y'all think I'm just ploying for a prize. You're wrong.

I get Ethan either way. I never gave a fuck about Italy. Y'all don't have leverage, you've just been left to run around far too long unsupervised. 

So now I will start collecting information. AL.com, The Crimson White, TuscaloosaNews, The NYTimes, TPD, and more will be interested to hear of the White Savior Society tricking eighteen year olds into thinking Rip Van Winkle bullshit is a college education. Or that TrumanShow-HungerGames is an appropriate way to build community. 

If you think I'll let you steal my story, you're fucking wrong. If you think I'll let you steal Ethan, you're fucking wrong. Time's up.

Resolved: The University Fellows Experience is a criminal syndicate which exploits talented youth with emotional manipulation and hypnosis to feed the cold and empty hearts of academic middle age, and therefore ought to be immediately abolished. 

Mark my words: everyone on campus will know my story by the end of the day. Fellows will not exist in August 2023. Don't expect a wedding invitation.

COLLEGE SHOULD NOT BE SOMETHING I HAVE TO ESCAPE FROM

FUCK YOU IF YOU DISAGREE.

SAM
"""

from alacorder import alac