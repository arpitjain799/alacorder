# alacorder beta 0.5.8

Runs on Python >=3.7
Preferred installation via pip in virtual environment
Recommended setup in iPython terminal in Anaconda virtual environment

Dependencies:
	 *	cython			https://pypi.org/project/Cython/
	 *  PyPDF2			https://pypi.org/project/PyPDF2/
	 *	pandas			https://pypi.org/project/pandas/
	 *  xlrd			https://pypi.org/project/xlrd/
	 *  openpyxl		https://pypi.org/project/openpyxl/
	 *  xlwt			https://pypi.org/project/xlwt/
	 	 
For command line interface:
	import alacorder
	

