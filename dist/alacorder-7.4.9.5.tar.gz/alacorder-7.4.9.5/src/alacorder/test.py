import alac

a = alac.config("/Users/samuelrobson/Desktop/PartialPickle.pkl.xz",
"/Users/samuelrobson/Desktop/PICKLES.csv",flags="filing")

alac.writeCharges(a)